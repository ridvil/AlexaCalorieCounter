# -*- coding: utf-8 -*-

# This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK for Python.
# Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
# session persistence, api calls, and more.
# This sample is built using the handler classes approach in skill builder.
import logging
import ask_sdk_core.utils as ask_utils

# import persistence adapter
import os
import boto3
import random
#from ask_sdk_core.skill_builder import CustomSkillBuilder
from ask_sdk.standard import StandardSkillBuilder
from ask_sdk_dynamodb.adapter import DynamoDbAdapter
from ask_sdk_core.dispatch_components import AbstractRequestInterceptor
from ask_sdk_core.dispatch_components import AbstractResponseInterceptor

# initialize persistence adapter
#ddb_region = os.environ.get('DYNAMODB_PERSISTENCE_REGION')
#ddb_table_name = os.environ.get('DYNAMODB_PERSISTENCE_TABLE_NAME')

#ddb_resource = boto3.resource('dynamodb', region_name=ddb_region)
#dynamodb_adapter = DynamoDbAdapter(table_name=ddb_table_name, create_table=False, dynamodb_resource=ddb_resource)

from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.dispatch_components import AbstractExceptionHandler
from ask_sdk_core.handler_input import HandlerInput

from ask_sdk_model import Response

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

class LaunchRequestHandler(AbstractRequestHandler):
    """Handler for Skill Launch."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool

        return ask_utils.is_request_type("LaunchRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        
        speak_output = "Welcome to Calorie Counter what can I do for you today?"
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )
class Goalweightintent(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("IntentRequest")(handler_input) and ask_utils.is_intent_name("GoalWeightIntent")(handler_input)
    def handle(self, handler_input):
        speak_output = ''
        attr = handler_input.attributes_manager.session_attributes
        goalWeight = ask_utils.request_util.get_slot(handler_input, 'GoalWeight').value
        attr['GoalWeight'] = goalWeight 
        handler_input.attributes_manager.session_attributes = attr
        #handler_input.attributes_manager.save_persistent_attributes()
        speak_output = f'Okay, I can set your goal weight to {goalWeight} pounds'
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
            )
class getGoalWeight(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("IntentRequest")(handler_input) and ask_utils.is_intent_name("GetGoalWeight")(handler_input)
    def handle(self, handler_input):
        speak_output = ''
        attr = handler_input.attributes_manager.persistent_attributes
        goalweight = attr['GoalWeight']
        speak_output = f'Your goal weight is {goalweight} pounds'
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
            )
class setMaintenanceCalories(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("IntentRequest")(handler_input) and ask_utils.is_intent_name('SetMaintenanceCalories')(handler_input)
    def handle(self, handler_input):
        speak_output = ''
        attr = handler_input.attributes_manager.session_attributes
        maintenanceCalories = ask_utils.request_util.get_slot(handler_input, 'maintenanceCalories').value
        attr['maintenanceCalories'] = maintenanceCalories
        handler_input.attributes_manager.session_attributes = attr
        #handler_input.attributes_manager.save_persistent_attributes()
        speak_output = f'Okay, I can set your maintenance calories to {maintenanceCalories} calories'
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
            )
class getMaintenanceCalories(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("IntentRequest")(handler_input) and ask_utils.is_intent_name('getMaintenanceCalories')(handler_input)
    def handle(self, handler_input):
        speak_output = ''
        attr = handler_input.attributes_manager.session_attributes
        maintenanceCalories = attr['maintenanceCalories']
        speak_output = f'Your maintenance calories are {maintenanceCalories} calories'
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
            )
class addFoodItemIntent(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("IntentRequest")(handler_input) and ask_utils.is_intent_name("addFoodInfo")(handler_input)
    def handle(self, handler_input):
        speak_output = ''
        attr = handler_input.attributes_manager.session_attributes
        foodItem = ask_utils.request_util.get_slot(handler_input, 'foodItem').value
        calorieInfo = ask_utils.request_util.get_slot(handler_input, 'calorieInfo').value
        numberOf = ask_utils.request_util.get_slot(handler_input, 'numberOf').value
        attr['numberOf'] = numberOf
        attr['foodItem'] = foodItem
        attr['calorieInfo'] = calorieInfo
        handler_input.attributes_manager.session_attributes = attr
        #handler_input.attributes_manager.save_persistent_attributes()
        speak_output = f'Okay, I can add {numberOf} {foodItem} at {calorieInfo} calories'
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
            )
class getFoodInfoIntent(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("IntentRequest")(handler_input) and ask_utils.is_intent_name("getFoodInfo")(handler_input)
    def handle(self, handler_input):
        speak_output = ''
        attr = handler_input.attributes_manager.persistent_attributes
        numberOf = attr['numberOf']
        foodItem = attr['foodItem']
        calorieInfo = attr['calorieInfo']
        speak_output = f'You ate {numberOf} {foodItem} at {calorieInfo} calories'
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
            )
class calorieLimitIntent(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("IntentRequest")(handler_input) and ask_utils.is_intent_name("CalorieLimit")(handler_input)
    def handle(self, handler_input):
        speak_output = ''
        limit = ask_utils.request_util.get_slot(handler_input, "calorieLimitNum").value
        attr = handler_input.attributes_manager.session_attributes
        attr["limit"] = limit
        handler_input.attributes_manager.session_attributes = attr
        #handler_input.attributes_manager.save_persistent_attributes()
        speak_output = f'Okay, I can set your calorie limit to {limit} calories'
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
            )
class getCalorieLimit(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("IntentRequest")(handler_input) and ask_utils.is_intent_name("getCalorieLimit")(handler_input)
    def handle(self, handler_input):
        speak_output = ''
        attr = handler_input.attributes_manager.persistent_attributes
        limit = attr['limit']
        speak_output = f'Your calorie limit is {limit} calories'
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
            )
class percentageIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("IntentRequest")(handler_input) and ask_utils.is_intent_name("percentage")(handler_input)

    def handle(self, handler_input):
        totalDayCalories = 2000
        calorieLimit = 2500
        caloriePercentage = (totalDayCalories / calorieLimit) * 100
        speak_output = f"Your calorie percentage is {caloriePercentage}% for the day"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )
class setDietRestrict(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("IntentRequest")(handler_input) and ask_utils.is_intent_name("setDietRestrict")(handler_input)
    def handle(self, handler_input):
        speak_output = ''
        diet = ask_utils.request_util.get_slot(handler_input, "diet").value
        attr = handler_input.attributes_manager.session_attributes
        attr["diet"] = diet
        handler_input.attributes_manager.session_attributes = attr
        speak_output = f'I set your diet restriction to {diet}'
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
            )
class getDietRestrict(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("IntentRequest")(handler_input) and ask_utils.is_intent_name("getDietRestrict")(handler_input)
    def handle(self, handler_input):
        speak_output = ''
        attr = handler_input.attributes_manager.session_attributes
        diet = attr['diet']
        speak_output = f'Your diet restriction is {diet}'
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
            )
class FoodFactIntentHandler(AbstractRequestHandler):
    """Handler for food fact Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("foodFacts")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        foodFacts = [
        "Pumpkin flowers are edible.",
        "The rows of corn are always an even number.",
        "The pumpkin originated in Mexico.",
        "Carrots have zero fat content.",
        "A watermelon's weight is about 92% water.",
        "There are more than 10,000 different varieties of tomatoes.",
        "Dynamite often uses peanuts as one of its components when being made.",
        "You can cure your hiccups with a spoonful of sugar.",
        "You can gain calories by licking stamps.", 
        "Lachanophobia is a fear of vegetables.",
        "Ketchup was once used as medicine.",
        "Mageirocophobia is a fear of cooking.",
        "Kentucky has a law that forbids you to carrry an ice cream cone in your back pocket.",
        "Grape growing is recognized to be the largest food industry in the world.",
        "Termites and ants are roasted and eaten like popcorn in South Africa.",
        "The average person eats a total of eight pounds of grapes annually.",
        "There are over 7,000 different varieties of apples in the world.",
        "Ripe cranberries are bouncy.",
        "One cluster of bananas is called a hand.",
        "A single banana is  called a finger.",
        "All bananas are clones of each other.",
        "133 is the record of the most eaten grapes in 3 minutes.",
        "Square watermelons cost more than round ones.",
        "Turning a pineapple upside-down will make it ripe faster.",
        "Juicy fruit gum is more than 100 years old.",
        "The swiss are known to eat the most chocolate in the world.",
        "Kit Kat was bought out by Nestle.",
        "Most cheese products contain less than 51% cheese.",
        "On average, Americans eat 28 pigs in their lifetime.",
        "Egg yolks natrually contain Vitamin D.",
        "National Pigs in a Blanket Day is celebrated in the U.S. every year.",
        "Chicken nuggets contain beef additives.",
        "French fries originally come from Belgium, not France.",
        "The average person will consume at least 12 pubic hairs annually from fast food services.",
        "France once only allowed the members of the royal court to consume chocolate.",
        "Baked beans are low in fat.",
        "Worcestershire sauce is made from fish that were dissolved.",
        "The roast camel is the largest menu item in the world.",
        "Anchovies are the least liked pizza toppings.",
        "White chocolate isn’t chocolate.",
        "You can turn coal mixed in peanut butter into a diamond.",
        "Green, red, and yellow bell peppers are not the same vegetables.",
        "Fruit snacks are coated in wax.",
        "The popsicle was invented by an 11-year-old.",
        "Apple pie is not American.",
        "The red dye used on Skittles comes from boiled beetles.",
        "The raw oysters you eat are still alive.",
        "Chocolate was once used as currency.",
        "Crackers give you cavities faster than candy.",
        "Chili peppers are not spicy.",
        "Over 16 billion jelly beans are prepared for Easter.",
        "Mass-produced ice creams commonly have seaweed in them.",
        "October is recognized as National Pasta Month in the United States.",
        "There are over 600 different types of pasta shapes produced worldwide.",
        "Gummy bears span to a length of 79 millimeters.",
        "It takes 6 bites to fully consume the average hot dog.",
        "A pineapple plant can only produce one pineapple a year.",
        "The lettuce is a part of the sunflower family.",
        "The second most popular fresh vegetable is lettuce.",
        "Blueberries contain high sources of Vitamin C."
    ]
        speak_output = random.choice(foodFacts)

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )
class QuickstartIntentHandler(AbstractRequestHandler):
    """Handler for Quickstart Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("QuickStart")(handler_input)
    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = """"
        Okay, let’s get started! To add meals you can try saying things like 
        “I want to add this food item it was this amount of calories. After that I’ll add the calories for you. 
        You can also set your weight goals by telling me something like “I want to lose or gain  this amount of pounds per week.” 
        Then I will save that to your profile.  To set your maintenance calories you can simply say “I want to set my maintenance calories.” To set 
        a calorie limit you can just say “Set my calorie limit to this amount.” I can also tell you your calorie percentage. If you want 
        to know, you can just ask “What is my calorie percentage?” Okay that’s it for the quick start guide, have fun!
        """
        reprompt = "I didn't catch that. Did you want to go through our guide?"

        return (
             handler_input.response_builder
                .speak(speak_output)
                .ask(reprompt)
                .response
        )
class WeightPerWeekHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("IntentRequest")(handler_input) and ask_utils.is_intent_name("WeightPerWeek")(handler_input)
        
    def handle(self, handler_input):
        speak_output = ''
        poundsPerWeek = ask_utils.request_util.get_slot(handler_input, "poundsPerWeek").value
        totalCalories = (int(poundsPerWeek) * 3500) / 7
        
        if(int(poundsPerWeek) > 2):
            speak_output = 'It can be dangerous to lose or gain more than 2 pounds in a week, please pick a different weight'
            return(
                handler_input.response_builder
                    .speak(speak_output)
                    #.ask(speak_output)
                    .response
                )
        else:
            speak_output = f"Okay, you have to eat {totalCalories} less per day to lose {poundsPerWeek} per week or eat {poundsPerWeek} more to gain"
            return(
                handler_input.response_builder
                    .speak(speak_output)
                    .response
                )
class HelloWorldIntentHandler(AbstractRequestHandler):
    """Handler for Hello World Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("HelloWorldIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Hello World!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class HelloWorldIntentHandler(AbstractRequestHandler):
    """Handler for Hello World Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("HelloWorldIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Hello World!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )


class HelpIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.HelpIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "You can say hello to me! How can I help?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )


class CancelOrStopIntentHandler(AbstractRequestHandler):
    """Single handler for Cancel and Stop Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return (ask_utils.is_intent_name("AMAZON.CancelIntent")(handler_input) or
                ask_utils.is_intent_name("AMAZON.StopIntent")(handler_input))

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Goodbye!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )

class FallbackIntentHandler(AbstractRequestHandler):
    """Single handler for Fallback Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.FallbackIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        logger.info("In FallbackIntentHandler")
        speech = "Hmm, I'm not sure. You can say Hello or Help. What would you like to do?"
        reprompt = "I didn't catch that. What can I help you with?"

        return handler_input.response_builder.speak(speech).ask(reprompt).response

class SessionEndedRequestHandler(AbstractRequestHandler):
    """Handler for Session End."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("SessionEndedRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response

        # Any cleanup logic goes here.

        return handler_input.response_builder.response


class IntentReflectorHandler(AbstractRequestHandler):
    """The intent reflector is used for interaction model testing and debugging.
    It will simply repeat the intent the user said. You can create custom handlers
    for your intents by defining them above, then also adding them to the request
    handler chain below.
    """
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("IntentRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        intent_name = ask_utils.get_intent_name(handler_input)
        speak_output = "You just triggered " + intent_name + "."

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )
class LoadDataInterceptor(AbstractRequestInterceptor):
    """Check if user is invoking skill for first time and initialize preset."""
    def process(self, handler_input):
        # type: (HandlerInput) -> None
        persistent_attributes = handler_input.attributes_manager.persistent_attributes
        session_attributes = handler_input.attributes_manager.session_attributes

        # ensure important variables are initialized so they're used more easily in handlers.
        # This makes sure they're ready to go and makes the handler code a little more readable
        if 'GoalWeight' not in session_attributes:
            session_attributes["GoalWeight"] = 0

        if 'maintenanceCalories' not in session_attributes:
            session_attributes["maintenanceCalories"] = 0

        if 'numberOf' not in persistent_attributes:
            session_attributes["numberOf"] = 0

        if 'foodItem' not in session_attributes:
            session_attributes["foodItem"] = None
        
        if 'calorieInfo' not in session_attributes:
            session_attributes["calorieInfo"] = 0
        
        if 'limit' not in session_attributes:
            session_attributes["limit"] = 0
            
        if 'diet' not in session_attributes:
            session_attributes['diet'] = None

        
        session_attributes["GoalWeight"] = persistent_attributes["GoalWeight"] if 'GoalWeight' in persistent_attributes else 0
        session_attributes["maintenanceCalories"] = persistent_attributes["maintenanceCalories"] if 'maintenanceCalories' in persistent_attributes else 0
        session_attributes["numberOf"] = persistent_attributes["numberOf"] if 'numberOf' in persistent_attributes else 0
        session_attributes["foodItem"] = persistent_attributes["foodItem"] if 'foodItem' in persistent_attributes else None
        session_attributes['calorieInfo'] = persistent_attributes['calorieInfo'] if 'calorieInfo' in persistent_attributes else 0
        session_attributes["limit"] = persistent_attributes["limit"] if 'limit' in persistent_attributes else 0
        session_attributes["diet"] = persistent_attributes["diet"] if 'diet' in persistent_attributes else None

        
class LoggingRequestInterceptor(AbstractRequestInterceptor):
    """Log the alexa requests."""
    def process(self, handler_input):
        # type: (HandlerInput) -> None
        logger.debug('----- REQUEST -----')
        logger.debug("{}".format(
            handler_input.request_envelope.request))

class SaveDataInterceptor(AbstractResponseInterceptor):
    """Save persistence attributes before sending response to user."""
    def process(self, handler_input, response):
        # type: (HandlerInput, Response) -> None
        persistent_attributes = handler_input.attributes_manager.persistent_attributes
        session_attributes = handler_input.attributes_manager.session_attributes

        persistent_attributes["GoalWeight"] = session_attributes["GoalWeight"] 
        persistent_attributes["maintenanceCalories"] = session_attributes["maintenanceCalories"]
        persistent_attributes['numberOf'] = session_attributes['numberOf']
        persistent_attributes['foodItem'] = session_attributes['foodItem']
        persistent_attributes['calorieInfo'] = session_attributes['calorieInfo']
        persistent_attributes['limit'] = session_attributes['limit']
        persistent_attributes['diet'] = session_attributes['diet']

        handler_input.attributes_manager.save_persistent_attributes()

class LoggingResponseInterceptor(AbstractResponseInterceptor):
    """Log the alexa responses."""
    def process(self, handler_input, response):
        # type: (HandlerInput, Response) -> None
        logger.debug('----- RESPONSE -----')
        logger.debug("{}".format(response))
        

class CatchAllExceptionHandler(AbstractExceptionHandler):
    """Generic error handling to capture any syntax or routing errors. If you receive an error
    stating the request handler chain is not found, you have not implemented a handler for
    the intent being invoked or included it in the skill builder below.
    """
    def can_handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> bool
        return True

    def handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> Response
        logger.error(exception, exc_info=True)

        speak_output = "Sorry, I had trouble doing what you asked. Please try again."

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )
class LoadDataInterceptor(AbstractRequestInterceptor):
    """Check if user is invoking skill for first time and initialize preset."""
    def process(self, handler_input):
        # type: (HandlerInput) -> None
        persistent_attributes = handler_input.attributes_manager.persistent_attributes
        session_attributes = handler_input.attributes_manager.session_attributes

        # ensure important variables are initialized so they're used more easily in handlers.
        # This makes sure they're ready to go and makes the handler code a little more readable
        if 'GoalWeight' not in session_attributes:
            session_attributes["GoalWeight"] = 0

        if 'maintenanceCalories' not in session_attributes:
            session_attributes["maintenanceCalories"] = 0

        if 'numberOf' not in persistent_attributes:
            session_attributes["numberOf"] = 0

        if 'foodItem' not in session_attributes:
            session_attributes["foodItem"] = None
        
        if 'calorieInfo' not in session_attributes:
            session_attributes["calorieInfo"] = 0
        
        if 'limit' not in session_attributes:
            session_attributes["limit"] = 0
        
        if 'diet' not in session_attributes:
            session_attributes['diet'] = None
        
        session_attributes["GoalWeight"] = persistent_attributes["GoalWeight"] if 'GoalWeight' in persistent_attributes else 0
        session_attributes["maintenanceCalories"] = persistent_attributes["maintenanceCalories"] if 'maintenanceCalories' in persistent_attributes else 0
        session_attributes["numberOf"] = persistent_attributes["numberOf"] if 'numberOf' in persistent_attributes else 0
        session_attributes["foodItem"] = persistent_attributes["foodItem"] if 'foodItem' in persistent_attributes else None
        session_attributes['calorieInfo'] = persistent_attributes['calorieInfo'] if 'calorieInfo' in persistent_attributes else 0
        session_attributes["limit"] = persistent_attributes["limit"] if 'limit' in persistent_attributes else 0
        session_attributes["diet"] = persistent_attributes["diet"] if 'diet' in persistent_attributes else None
        
class LoggingRequestInterceptor(AbstractRequestInterceptor):
    """Log the alexa requests."""
    def process(self, handler_input):
        # type: (HandlerInput) -> None
        logger.debug('----- REQUEST -----')
        logger.debug("{}".format(
            handler_input.request_envelope.request))

# The SkillBuilder object acts as the entry point for your skill, routing all request and response
# payloads to the handlers above. Make sure any new handlers or interceptors you've
# defined are included below. The order matters - they're processed top to bottom.


#sb = CustomSkillBuilder(persistence_adapter = dynamodb_adapter)
sb = StandardSkillBuilder(
    table_name=os.environ.get("DYNAMODB_PERSISTENCE_TABLE_NAME"), auto_create_table=False)

sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(Goalweightintent())
sb.add_request_handler(getGoalWeight())
sb.add_request_handler(setMaintenanceCalories())
sb.add_request_handler(getMaintenanceCalories())
sb.add_request_handler(addFoodItemIntent())
sb.add_request_handler(getFoodInfoIntent())
sb.add_request_handler(calorieLimitIntent())
sb.add_request_handler(getCalorieLimit())
sb.add_request_handler(percentageIntentHandler())
sb.add_request_handler(setDietRestrict())
sb.add_request_handler(getDietRestrict())
sb.add_request_handler(FoodFactIntentHandler())
sb.add_request_handler(QuickstartIntentHandler())
sb.add_request_handler(WeightPerWeekHandler())
sb.add_request_handler(HelloWorldIntentHandler())
sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(CancelOrStopIntentHandler())
sb.add_request_handler(FallbackIntentHandler())
sb.add_request_handler(SessionEndedRequestHandler())
sb.add_request_handler(IntentReflectorHandler()) # make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers

sb.add_exception_handler(CatchAllExceptionHandler())

sb.add_global_request_interceptor(LoadDataInterceptor())
sb.add_global_request_interceptor(LoggingRequestInterceptor())

sb.add_global_response_interceptor(SaveDataInterceptor())
sb.add_global_response_interceptor(LoggingResponseInterceptor())

lambda_handler = sb.lambda_handler()